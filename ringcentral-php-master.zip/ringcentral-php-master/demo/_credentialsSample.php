<?php

return array(
    'username'     => '18881112233', // your RingCentral account phone number
    'extension'    =>  null, // or number
    'password'     => 'yourPassword',
    'clientId'     => 'yourClientId',
    'clientSecret' => 'yourClientSecret',
    'server'       => 'https://platform.devtest.ringcentral.com', // for production - https://platform.ringcentral.com
    'smsNumber'    => '18882223344', // any of SMS-enabled numbers on your RingCentral account
    'mobileNumber' => '16501112233', // your own mobile number to which script will send sms
    'dateFrom'	   => 'yyyy-mm-dd',  // dateFrom
    'dateTo'       => 'yyyy-mm-dd'   // dateTo
);